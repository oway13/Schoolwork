Node Express Assignment
    Sessions
    Routing
    SQL

x500: kormi001
acc_login: alpha
acc_password: bravo