// Priority Queue and Simulation
// Event is the generic interface for a runnable agenda object.
//Downloaded From Lecture Notes. credit: Chris Dovolis

public interface Event {

    void run();

}
